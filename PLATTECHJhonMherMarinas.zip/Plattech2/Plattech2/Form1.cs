﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Plattech2
{
    public partial class PLATTECH : Form
    {
        //int[] ArrivalTime;
        List<int> ArrivalTime = new List<int>();
        List<int> burstTime = new List<int>();
        int aa, ba, ca, aP, bP, cP, aB, bB, cB, ab, bb, cb;

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void intOnly(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        public PLATTECH()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (PA_AT.Text == "" || PB_AT.Text == "" || PC_AT.Text == "" || PA_BT.Text == "" || PB_BT.Text == "" || PC_BT.Text == "")
            {
                MessageBox.Show("FILL UP ALL FORMS","ERROR");
            }
            else
            {
                ArrivalTime.Add(Int32.Parse(PA_AT.Text));
                ArrivalTime.Add(Int32.Parse(PB_AT.Text));
                ArrivalTime.Add(Int32.Parse(PC_AT.Text));
                burstTime.Add(Int32.Parse(PA_BT.Text));
                burstTime.Add(Int32.Parse(PB_BT.Text));
                burstTime.Add(Int32.Parse(PC_BT.Text));
                int totalArrival = ArrivalTime.Count;
                int temp;
                for (int j = 0; j <= totalArrival - 2; j++)
                {
                    for (int i = 0; i <= totalArrival - 2; i++)
                    {
                        if (ArrivalTime[i] > ArrivalTime[i + 1])
                        {
                            temp = ArrivalTime[i + 1];
                            ArrivalTime[i + 1] = ArrivalTime[i];
                            ArrivalTime[i] = temp;
                        }
                    }
                }
                GetArrangement();
            }
        }      
        void GetArrangement()
        {
            aa = Int32.Parse(PA_AT.Text);
            ba = Int32.Parse(PB_AT.Text);
            ca = Int32.Parse(PC_AT.Text);
            aP = ArrivalTime[0];
            bP = ArrivalTime[1];
            cP = ArrivalTime[2];
            if (aa == aP)
            {
                G1.Text = PlabelA.Text;
                burstTime[0] = Int32.Parse(PB_BT.Text);
                if (bP == ba)
                {
                    G2.Text = Plabelb.Text;
                    burstTime[1] = Int32.Parse(PB_BT.Text);
                    G3.Text = PlabelC.Text;
                    burstTime[2] = Int32.Parse(PC_BT.Text);

                }
                else if (bP == ca)
                {
                    G2.Text = PlabelC.Text;
                    burstTime[1] = Int32.Parse(PC_BT.Text);
                    G3.Text = Plabelb.Text;
                    burstTime[2] = Int32.Parse(PB_BT.Text);
                }
            }
            if (ba == aP)
            {
                G1.Text = Plabelb.Text;
                burstTime[0] = Int32.Parse(PB_BT.Text);
                if (bP == aa)
                {
                    G2.Text = PlabelA.Text;
                    burstTime[1] = Int32.Parse(PA_BT.Text);
                    G3.Text = PlabelC.Text;
                    burstTime[2] = Int32.Parse(PC_BT.Text);

                }
                else if (bP == ca)
                {
                    G2.Text = PlabelC.Text;
                    burstTime[1] = Int32.Parse(PC_BT.Text);
                    G3.Text = PlabelA.Text;
                    burstTime[2] = Int32.Parse(PA_BT.Text);
                }
            }
            if (ca == aP)
            {
                G1.Text = PlabelC.Text;
                burstTime[0] = Int32.Parse(PC_BT.Text);
                if (bP == aa)
                {
                    G2.Text = PlabelA.Text;
                    burstTime[1] = Int32.Parse(PA_BT.Text);
                    G3.Text = Plabelb.Text;
                    burstTime[2] = Int32.Parse(PB_BT.Text);

                }
                else if (bP == ba)
                {
                    G2.Text = Plabelb.Text;
                    burstTime[1] = Int32.Parse(PB_BT.Text);
                    G3.Text = PlabelA.Text;
                    burstTime[2] = Int32.Parse(PA_BT.Text);
                }
            }
            aB = burstTime[0];
            bB = burstTime[1];
            cB = burstTime[2];
            //HiddenJitsu "LabelDisplay"
            int bAdd = aB + bB;
            int bAdd2 = bAdd + cB;
            label1.Text = ArrivalTime[0].ToString();
            label2.Text = aB.ToString();
            label3.Text = bAdd.ToString();
            label4.Text = bAdd2.ToString();

        }
        void clear()
        {
            PA_AT.Text = "";
            PB_AT.Text = "";
            PC_AT.Text = "";
            PA_BT.Text = "";
            PB_BT.Text = "";
            PC_BT.Text = "";
            G1.Text = "";
            G2.Text = "";
            G3.Text = "";
            label1.Text = "0";
            label2.Text = "0";
            label3.Text = "0";
            label4.Text = "0";
        }
       
    }
}
