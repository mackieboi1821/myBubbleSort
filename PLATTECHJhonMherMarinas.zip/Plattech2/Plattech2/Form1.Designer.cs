﻿namespace Plattech2
{
    partial class PLATTECH
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.G3 = new System.Windows.Forms.TextBox();
            this.G2 = new System.Windows.Forms.TextBox();
            this.G1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.Blabel = new System.Windows.Forms.Label();
            this.ATlabel = new System.Windows.Forms.Label();
            this.PlabelC = new System.Windows.Forms.Label();
            this.Plabelb = new System.Windows.Forms.Label();
            this.PlabelA = new System.Windows.Forms.Label();
            this.PC_BT = new System.Windows.Forms.TextBox();
            this.PB_BT = new System.Windows.Forms.TextBox();
            this.PA_BT = new System.Windows.Forms.TextBox();
            this.PC_AT = new System.Windows.Forms.TextBox();
            this.PB_AT = new System.Windows.Forms.TextBox();
            this.PA_AT = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(402, 163);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(16, 18);
            this.label4.TabIndex = 37;
            this.label4.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(293, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(16, 18);
            this.label3.TabIndex = 36;
            this.label3.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(187, 163);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 18);
            this.label2.TabIndex = 35;
            this.label2.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(81, 163);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 18);
            this.label1.TabIndex = 34;
            this.label1.Text = "0";
            // 
            // G3
            // 
            this.G3.Location = new System.Drawing.Point(305, 140);
            this.G3.Name = "G3";
            this.G3.ReadOnly = true;
            this.G3.Size = new System.Drawing.Size(100, 20);
            this.G3.TabIndex = 33;
            // 
            // G2
            // 
            this.G2.Location = new System.Drawing.Point(199, 140);
            this.G2.Name = "G2";
            this.G2.ReadOnly = true;
            this.G2.Size = new System.Drawing.Size(100, 20);
            this.G2.TabIndex = 32;
            // 
            // G1
            // 
            this.G1.Location = new System.Drawing.Point(93, 140);
            this.G1.Name = "G1";
            this.G1.ReadOnly = true;
            this.G1.Size = new System.Drawing.Size(100, 20);
            this.G1.TabIndex = 31;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button1.Cursor = System.Windows.Forms.Cursors.Default;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(387, 45);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(71, 35);
            this.button1.TabIndex = 30;
            this.button1.Text = "Compute";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Blabel
            // 
            this.Blabel.AutoSize = true;
            this.Blabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Blabel.Location = new System.Drawing.Point(276, 26);
            this.Blabel.Name = "Blabel";
            this.Blabel.Size = new System.Drawing.Size(72, 16);
            this.Blabel.TabIndex = 29;
            this.Blabel.Text = "Burst Time";
            // 
            // ATlabel
            // 
            this.ATlabel.AutoSize = true;
            this.ATlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ATlabel.Location = new System.Drawing.Point(138, 26);
            this.ATlabel.Name = "ATlabel";
            this.ATlabel.Size = new System.Drawing.Size(80, 16);
            this.ATlabel.TabIndex = 28;
            this.ATlabel.Text = "Arrival Time";
            // 
            // PlabelC
            // 
            this.PlabelC.AutoSize = true;
            this.PlabelC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PlabelC.Location = new System.Drawing.Point(39, 101);
            this.PlabelC.Name = "PlabelC";
            this.PlabelC.Size = new System.Drawing.Size(70, 16);
            this.PlabelC.TabIndex = 27;
            this.PlabelC.Text = "Process C";
            // 
            // Plabelb
            // 
            this.Plabelb.AutoSize = true;
            this.Plabelb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Plabelb.Location = new System.Drawing.Point(39, 75);
            this.Plabelb.Name = "Plabelb";
            this.Plabelb.Size = new System.Drawing.Size(70, 16);
            this.Plabelb.TabIndex = 26;
            this.Plabelb.Text = "Process B";
            // 
            // PlabelA
            // 
            this.PlabelA.AutoSize = true;
            this.PlabelA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PlabelA.Location = new System.Drawing.Point(39, 45);
            this.PlabelA.Name = "PlabelA";
            this.PlabelA.Size = new System.Drawing.Size(70, 16);
            this.PlabelA.TabIndex = 25;
            this.PlabelA.Text = "Process A";
            // 
            // PC_BT
            // 
            this.PC_BT.Location = new System.Drawing.Point(262, 97);
            this.PC_BT.Name = "PC_BT";
            this.PC_BT.Size = new System.Drawing.Size(100, 20);
            this.PC_BT.TabIndex = 24;
            this.PC_BT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.PC_BT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.intOnly);
            // 
            // PB_BT
            // 
            this.PB_BT.Location = new System.Drawing.Point(262, 71);
            this.PB_BT.Name = "PB_BT";
            this.PB_BT.Size = new System.Drawing.Size(100, 20);
            this.PB_BT.TabIndex = 23;
            this.PB_BT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.PB_BT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.intOnly);
            // 
            // PA_BT
            // 
            this.PA_BT.Location = new System.Drawing.Point(262, 45);
            this.PA_BT.Name = "PA_BT";
            this.PA_BT.Size = new System.Drawing.Size(100, 20);
            this.PA_BT.TabIndex = 22;
            this.PA_BT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.PA_BT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.intOnly);
            // 
            // PC_AT
            // 
            this.PC_AT.Location = new System.Drawing.Point(124, 97);
            this.PC_AT.Name = "PC_AT";
            this.PC_AT.Size = new System.Drawing.Size(100, 20);
            this.PC_AT.TabIndex = 21;
            this.PC_AT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.PC_AT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.intOnly);
            // 
            // PB_AT
            // 
            this.PB_AT.Location = new System.Drawing.Point(124, 71);
            this.PB_AT.Name = "PB_AT";
            this.PB_AT.Size = new System.Drawing.Size(100, 20);
            this.PB_AT.TabIndex = 20;
            this.PB_AT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.PB_AT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.intOnly);
            // 
            // PA_AT
            // 
            this.PA_AT.Location = new System.Drawing.Point(124, 45);
            this.PA_AT.Name = "PA_AT";
            this.PA_AT.Size = new System.Drawing.Size(100, 20);
            this.PA_AT.TabIndex = 19;
            this.PA_AT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.PA_AT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.intOnly);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button2.Cursor = System.Windows.Forms.Cursors.Default;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(387, 89);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(71, 35);
            this.button2.TabIndex = 38;
            this.button2.Text = "Clear";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // PLATTECH
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(505, 215);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.G3);
            this.Controls.Add(this.G2);
            this.Controls.Add(this.G1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Blabel);
            this.Controls.Add(this.ATlabel);
            this.Controls.Add(this.PlabelC);
            this.Controls.Add(this.Plabelb);
            this.Controls.Add(this.PlabelA);
            this.Controls.Add(this.PC_BT);
            this.Controls.Add(this.PB_BT);
            this.Controls.Add(this.PA_BT);
            this.Controls.Add(this.PC_AT);
            this.Controls.Add(this.PB_AT);
            this.Controls.Add(this.PA_AT);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "PLATTECH";
            this.Text = "PLAT TECH";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox G3;
        private System.Windows.Forms.TextBox G2;
        private System.Windows.Forms.TextBox G1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label Blabel;
        private System.Windows.Forms.Label ATlabel;
        private System.Windows.Forms.Label PlabelC;
        private System.Windows.Forms.Label Plabelb;
        private System.Windows.Forms.Label PlabelA;
        private System.Windows.Forms.TextBox PC_BT;
        private System.Windows.Forms.TextBox PB_BT;
        private System.Windows.Forms.TextBox PA_BT;
        private System.Windows.Forms.TextBox PC_AT;
        private System.Windows.Forms.TextBox PB_AT;
        private System.Windows.Forms.TextBox PA_AT;
        private System.Windows.Forms.Button button2;
    }
}

